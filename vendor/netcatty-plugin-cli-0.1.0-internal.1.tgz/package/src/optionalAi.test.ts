import assert from 'node:assert/strict';
import test from 'node:test';
import { validateManifestValue } from './manifest.js';
import { checkPluginCompatibility } from './compatibility.js';
import type { PluginManifest } from '@netcatty/plugin-contract';

const manifest: PluginManifest = {
  manifestVersion: 1, id: 'com.example.sql-draft', name: 'sql-draft', displayName: 'SQL draft',
  version: '0.1.0', publisher: 'example', license: 'MIT',
  engines: { netcatty: '>=0.0.0', api: '>=0.1.0-internal.1 <0.2.0' },
  main: { browser: 'browser.js' }, activationEvents: ['onStartupFinished'],
  features: { optional: ['ai.model-invocation'] },
  permissions: { optional: [{ permission: 'ai.invoke', resources: ['*'], reason: 'Unexecuted drafts' }] },
};

test('optional AI declaration loads without host AI and negotiates it only when supported', () => {
  assert.equal(validateManifestValue(manifest).valid, true, JSON.stringify(validateManifestValue(manifest).errors));
  for (const features of [[], ['ai.model-invocation']]) {
    const result = checkPluginCompatibility(manifest, { netcattyVersion: '0.0.0', features });
    assert.equal(result.compatible, true);
    assert.deepEqual(result.enabledFeatures, features);
  }
});

test('AI permission still requires a declared feature; required feature still blocks incompatible hosts', () => {
  const missing = structuredClone(manifest); missing.features = {};
  assert.equal(validateManifestValue(missing).valid, false);
  const required = structuredClone(manifest); required.features = { required: ['ai.model-invocation'] };
  assert.equal(validateManifestValue(required).valid, true);
  assert.equal(checkPluginCompatibility(required, { netcattyVersion: '0.0.0', features: [] }).compatible, false);
});
